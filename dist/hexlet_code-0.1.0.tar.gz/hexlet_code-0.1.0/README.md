### Hexlet tests and linter status:
[![Actions Status](https://github.com/Heilig-Di/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Heilig-Di/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/124d468507bc648eaff9/maintainability)](https://codeclimate.com/github/Heilig-Di/python-project-49/maintainability)
